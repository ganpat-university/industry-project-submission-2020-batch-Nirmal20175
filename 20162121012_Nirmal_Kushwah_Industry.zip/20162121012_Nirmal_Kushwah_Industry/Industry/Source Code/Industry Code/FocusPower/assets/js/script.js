// function to open sub sidebar menu
function openSubMenu(index){
    const sidebarItem = document.getElementsByClassName('sidebarIcon');
    const subSidebarTitle = document.getElementsByClassName('subSidebarHeading');
    for (let itemIndex = 0; itemIndex < sidebarItem.length; itemIndex++) {
        if (sidebarItem[itemIndex].classList.contains('openSubSidebar')) {
            sidebarItem[itemIndex].classList.remove('openSubSidebar'); 
        }
    }

    for (let itemIndex = 0; itemIndex < subSidebarTitle.length; itemIndex++) {
        if (subSidebarTitle[itemIndex].classList.contains('showSubSidebarHeading')) {
            subSidebarTitle[itemIndex].classList.remove('showSubSidebarHeading');
        }
        
    }
    sidebarItem[index].classList.add('openSubSidebar');
    subSidebarTitle[index].classList.add('showSubSidebarHeading');
}

// function to close sub sidebar menu
function closeSubSidebar(){
    const collapseSidebar = document.querySelector('.sidebarSubMenu')
    const sidebar = document.querySelector('.sidebarMenu');
    const content = document.querySelector('.contentBody');
    collapseSidebar.classList.add('toggleSubSideBar');
    sidebar.classList.add('sidebarBorder');
    content.classList.add('increaseContentWidth')
}

// function to open sub sidebar menu
function openSubSidebar(){
    const collapseSidebar = document.querySelector('.sidebarSubMenu')
    const sidebar = document.querySelector('.sidebarMenu');
    const content = document.querySelector('.contentBody');
    collapseSidebar.classList.remove('toggleSubSideBar');
    sidebar.classList.remove('sidebarBorder');
    content.classList.remove('increaseContentWidth')
}

// function to open hidden row
function showHiddenRow(n){
    const hiddenRows = document.getElementsByClassName('hiddenRow');
    const downArrow = document.getElementsByClassName('downArrow');
    const upArrow = document.getElementsByClassName('upArrow');
    hiddenRows[n].classList.add('open');
    downArrow[n].classList.add('hideDownArrow');
    upArrow[n].classList.add('showUpArrow');
}

// function to close hidden row
function closeHiddenRow(n){
    const hiddenRows = document.getElementsByClassName('hiddenRow');
    const downArrow = document.getElementsByClassName('downArrow');
    const upArrow = document.getElementsByClassName('upArrow');
    hiddenRows[n].classList.remove('open');
    downArrow[n].classList.remove('hideDownArrow');
    upArrow[n].classList.remove('showUpArrow');
}

// function to hide My feedback sections
function hideMyFeedback(){
    const getUpArrow = document.querySelector('.myFeedBackUpArrow');
    const getDownArrow = document.querySelector('.myFeedbackHidingArrow');
    const getSubContainer = document.querySelector('.myFeedBackSubContainer');
    const getHeaderContainer = document.querySelector('.myFeedBackHeaderContainer');
    const getMyFeedback = document.querySelector('.myFeedBack .subContainer');

    getUpArrow.classList.add('hideUpArrow');
    getDownArrow.classList.remove('myFeedBackDownArrow');
    getSubContainer.classList.add('hideMyFeedbackSubContainer');
    getHeaderContainer.classList.add('removeHeaderBorder');
    getMyFeedback.classList.add('smallMyFeedback');
}

// function to hide My feedback sections
function showMyFeedback(){
    const getUpArrow = document.querySelector('.myFeedBackUpArrow');
    const getDownArrow = document.querySelector('.myFeedbackHidingArrow');
    const getSubContainer = document.querySelector('.myFeedBackSubContainer');
    const getHeaderContainer = document.querySelector('.myFeedBackHeaderContainer');
    const getMyFeedback = document.querySelector('.myFeedBack .subContainer');

    getUpArrow.classList.remove('hideUpArrow');
    getDownArrow.classList.add('myFeedBackDownArrow');
    getSubContainer.classList.remove('hideMyFeedbackSubContainer');
    getHeaderContainer.classList.remove('removeHeaderBorder');
    getMyFeedback.classList.remove('smallMyFeedback');
}

// select year in my feedback
function selectYear(index){
    const getYears = document.getElementsByClassName('yearNumber');
    for (let yearIndex = 0; yearIndex < getYears.length; yearIndex++) {
        if (getYears[yearIndex].classList.contains('selectedYear')) {
            getYears[yearIndex].classList.remove('selectedYear');
        }
    }
    getYears[index].classList.add('selectedYear');
}