// -------------------- function for toggle account menu start -------------------------//
function showAccount(){
    // fetch toggle menu section
    const toggleMenu = document.querySelector('.toggleAccountMenu')
    toggleMenu.classList.toggle('open');
}
// -------------------- function for toggle account menu end -------------------------//

// -------------------- function to open and close left side bar start --------------------//
function closeSidebar(){
    const otherItem = document.querySelector('.otherItem .items');
    const content = document.querySelector('.content');
    otherItem.classList.toggle('.collapseOtherItem');
    content.classList.add('increaseWidth');
    document.getElementById('index').style.display = 'none';
    document.getElementById('index2').style.display = 'flex';
}

function openSidebar(){
    document.getElementById('index').style.display = 'flex';
    document.getElementById('index2').style.display = 'none';
    const content = document.querySelector('.content');
    content.classList.remove('increaseWidth');
}
// -------------------- function to open and close left side bar start --------------------//
