/*------------------------------------------------------------------------- function for toggle menu ------------------------------------------------------------------------- */
// function for toggle menu, when toggle button is clicked toggle menu should be shown
function showMenu() {
    // fetch toggle menu section
    const dropdownMenu = document.querySelector('.toggleMenu')
    // toggle open class in toggle menu class list
    dropdownMenu.classList.toggle('open');
}
/*------------------------------------------------------------------------- function for toggle menu end ------------------------------------------------------------------------- */

