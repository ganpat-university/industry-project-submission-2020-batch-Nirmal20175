window.onscroll = function(){myfunction()};


function mufunction() {
    if (document.documentElement.scrollTop > 10){
        document.getElementById("main-b-1-2").className = 'scroll-b-1-2';
    }
    else{
        document.getElementById("b-1-2").className = ''
    }
}